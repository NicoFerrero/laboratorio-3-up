#ifndef _GLOBAL_H
#define _GLOBAL_H
#include <pthread.h>

extern pthread_mutex_t mutex;

#endif
