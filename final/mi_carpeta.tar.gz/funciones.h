#ifndef _FUNCIONES_H
#define _FUNCIONES_H

void devolverNumero(int desde, int hasta);
int numeroAleatorio(int desde, int hasta);
int numeroAleatorioNoRepetitivo(int desde, int hasta, int numbers[], int *size);
#endif
