#ifndef _CLAVE_H
#define _CLAVE_H
#include "sys/ipc.h"

key_t crearClave(int base);

#endif
