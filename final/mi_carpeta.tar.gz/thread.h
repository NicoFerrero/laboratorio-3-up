#ifndef _THREAD_H
#define _THREAD_H
#include <pthread.h>

void *funcionThread(void *parametro);

#endif
