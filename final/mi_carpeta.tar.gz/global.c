#include <pthread.h>
#include "global.h"

pthread_mutex_t mutex;
pthread_cond_t cond;
